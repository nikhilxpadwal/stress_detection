import tkinter as tk
from tkinter import messagebox as ms
from tkinter import ttk, LEFT, END
from PIL import Image , ImageTk 
import numpy as np
from tkinter import messagebox as ms
import time

import pandas as pd
import joblib

from sklearn import preprocessing

# from sklearn.preprocessing import StandardScaler

import Stress_Detector_SVM as TM

from scipy import signal 

import warnings 
warnings.filterwarnings("ignore", category=DeprecationWarning)

basepath=r'F:\Stress_detection_ECGData\Stress_detection_ECGData\\'

##############################################+=============================================================
root = tk.Tk()
root.configure(background="seashell2")
#root.geometry("1300x700")


w, h = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry("%dx%d+0+0" % (w, h))
root.title("Stress_detection_system")
###################################################################################################################
ent1 = float()
ent2 = float()
ent3 = float()
ent4 = float()
ent5 = float()
ent6 = float()
#age = tk.IntVar()
# password = tk.StringVar()
# password1 = tk.StringVar()
##############################################+=============================================================
#####For background Image
image2 =Image.open('i1.jpg')
image2 =image2.resize((w,h), Image.ANTIALIAS)

background_image=ImageTk.PhotoImage(image2)

background_label = tk.Label(root, image=background_image)

background_label.image = background_image

background_label.place(x=0, y=0) #, relwidth=1, relheight=1)
#height=1, width=35,
lbl = tk.Label(root, text=" Stress Detection System Using Machine Learning Techniques. ", font=('times',30,' bold '),justify=tk.CENTER,bg="SkyBlue4",fg="white")
lbl.place(x=200, y=5)


#frame_display = tk.LabelFrame(root, text=" --Wave Form Data-- ", width=1380, height=350, bd=5, font=('times', 10, ' bold '),bg="blue3",fg="red")
#frame_display.grid(row=0, column=0, sticky='s')
#frame_display.place(x=180, y=60)



frame_alpr = tk.LabelFrame(root, text=" --Process-- ", width=180, height=450, bd=5, font=('times', 10, ' bold '),bg="purple")
frame_alpr.grid(row=0, column=0, sticky='nw')
frame_alpr.place(x=5, y=100)

###########################################################################################################
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
container_tree = tk.Frame(root, width=1200, height=350)
container_tree.propagate(False)
container_tree.place(x=200,y=100)
#container_tree.pack(side="left", fill='y')

tree = ttk.Treeview(container_tree, selectmode='browse')  #show="tree",
tree.heading("#0", text='*', anchor='w')
#tree.column("#0", anchor="w",width=0,stretch=False)
            
style = ttk.Style()
style.configure('Treeview', rowheight=30)
style.configure("Treeview.Heading", font=(None, 15),rowheight=150)
#style = ttk.Style()
style.configure(".", font=('Helvetica', 12), foreground="blue")
style.configure("Treeview", foreground='blue')
style.configure("Treeview.Heading", foreground='red',background='green') #<----

fr_y = tk.Frame(container_tree)
fr_y.pack(side='right', fill='y')
tk.Label(fr_y, borderwidth=1, relief='raised', font="Arial 8").pack(side='bottom', fill='x')
sb_y = tk.Scrollbar(fr_y, orient="vertical", command=tree.yview)
sb_y.pack(expand='yes', fill='y')
fr_x = tk.Frame(container_tree)
fr_x.pack(side='bottom', fill='x')
sb_x = tk.Scrollbar(fr_x, orient="horizontal", command=tree.xview)
sb_x.pack(expand='yes', fill='x')
tree.configure(yscrollcommand=sb_y.set, xscrollcommand=sb_x.set)
tree.pack(fill='both', expand='yes')
tree.column("#0", anchor="w",stretch=False)
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
################################################################################################################

def treeview_df(sd):
    
    df = sd
    cols = list(df.columns)
    
    tree.delete(*tree.get_children())
    
    tree["columns"] = cols
    for i in cols:
        tree.column(i, anchor="w")
        tree.heading(i, text=i, anchor='w')
    
    for index, row in df.iterrows():
        # print(row)
        tree.insert("",index,text=str(index+1),values= list(row))
        
def Load_data():
    
    data = pd.read_csv("E:/Stress_detection_ECGData/Stress_detection_ECGData/dataset/dataframe_hrv.csv")      #,names=columns, header=None) 

    treeview_df(data)
    
def Process_d():

    # dataframe_hrv = pd.read_csv("dataset/dataframe_hrv.csv") 
    # dataframe_hrv = dataframe_hrv.reset_index(drop=True)
    colset=['ECG', 'EMG', 'HR','RESP','footGSR', 'handGSR', 'stress']

    dataframe_hrv = pd.read_csv("dataset/dataframe_hrv.csv",usecols=colset)
    dataframe_hrv = dataframe_hrv.reset_index(drop=True)   
    dataframe_hrv.columns = ['ECG(mV)', 'EMG(mV)', 'HR(bpm)', 'RESP(mV)', 'Foot GSR(mV)', 'Hand GSR(mV)','Stress']

    
    def fix_stress_labels(df='',label_column='Stress'):
        df['Stress'] = np.where(df['Stress']>=0.5, 1, 0)
        return df
    
    
    def missing_values(df):
        
        # df = df.reset_index()
        df = df.replace([np.inf, -np.inf], np.nan)
        df[~np.isfinite(df)] = np.nan
        df['HR(bpm)'].fillna((df['HR(bpm)'].mean()), inplace=True)
        df['HR(bpm)'] = signal.medfilt(df['HR(bpm)'],13) 
    
        df.fillna(df.mean(),inplace=True)
        
        return df
    
    dataframe_hrv = fix_stress_labels(dataframe_hrv)
    dataframe_hrv = missing_values(dataframe_hrv)
    
    # dataframe_hrv=dataframe_hrv.reset_index(drop=True, inplace=True)

    # counts = dataframe_hrv['Stress'].value_counts()
    # print(counts[0], counts[1])
    
    
    treeview_df(dataframe_hrv )
    ms.showinfo("messege","process Data Successfully ")
##################################################################################################################
#def clear_img():
    
 #   img11 = tk.Label(frame_display, background='blue3',width=160,height=120)
  #  img11.place(x=0, y=0)

def update_label(str_T1,str_T2):
    # clear_img()
    result_label1 = tk.Label(root, text=str_T1, width=50, font=("bold", 15),bg='blue3',fg='black' )
    result_label1.place(x=180, y=480)
    
    result_label2 = tk.Label(root, text=str_T2, width=50, font=("bold", 15),bg='blue3',fg='black' )
    result_label2.place(x=880, y=480)
   
def train_model():
    start = time.time()

    update_label("Model Training Start...............", str(start))

    s=['Train']
    
    X1,X2=TM.main(False,s)

    end = time.time()

    ET="Execution Time: {0:.4} seconds \n".format(end-start)

    msg1="Model Training Completed.."+'\n'+ X1 + '\n' +  ET
    msg2="Model Training Completed.."+'\n'+ X2 + '\n' +  ET

    update_label(msg1,msg2)
#################################################################################################################
def test_window():
    # scaler = MinMaxScaler()
    def update_lblwin(textv):
        label = tk.Label(toproot,text="--- Test Result---",bg="lightSeaGreen",fg="white",font=('times', 15, ' bold '))
        label.config(text=textv)
        label.place(x=450,y=100)

    def testing():
           # ent1 = float.get()
           # ent2 = float.get()
           # ent3 = float.get()
           # ent4 = float.get()
           # ent5 = float.get()
           # ent6 = float.get()
        s=[str(ent1.get()),str(ent2.get()),str(ent3.get()),str(ent4.get()),str(ent5.get()),str(ent6.get())]
        #ms.showinfo("Message","showing result")       

           
        #s=['ent1','ent2','ent3','ent4','ent5','ent6'] 

        if len(s) == 6:
            
                    start = time.time()

                    pred = TM.main(True,s)
                    # Predict_get_value=clf.predict(output)
            
                    X=pred
            
                    print(X)
            
                    if X[0] == 0:
                        M = "Non Stress"
                    elif X[0] == 1:
                        M =  "Stress \n Please do Meditation and Exercise"
#                        ms.showorning("Message","Please do Meditation yoga and Excercise is good for your health.") 
                    
                    X1="The Reading is {0}".format(M)
            
                    end = time.time()
                
                    ET="Execution Time: {0:.4} seconds \n".format(end-start)
            
                    msg="Testing Completed.."+'\n'+ X1 + '\n'+ ET
            
                    update_lblwin(msg)
        else:
                    update_lblwin("Please Enter All the above Values for Proper testing !!")
                   # ms.showinfo("Message","showing result")       
#validation
        if (ent1 == ""):
               ms.showerror("Waring", "Please Enter Valid Entries")
        elif (ent2 == ""):
                ms.showerror("Waring", "Please Enter Valid Entries")   
        elif (ent3 == ""):
                ms.showerror("Waring", "Please Enter Valid Entries")  
        elif (ent4 == ""):
                ms.showerror("Waring", "Please Enter Valid Entries")
        elif (ent5 == ""):
               ms.showerror("Waring", "Please Enter Valid Entries")  
        elif (ent6 == ""):
                ms.showerror("Waring", "Please Enter Valid Entries")   
        else:
                ms.showinfo("Message","Showing Result")       
                ms.showinfo("Message", "Please Check Testing Window")
       
      
        
        
        
        
        
################################################################################################################################       
    toproot = tk.Toplevel(background="RoyalBlue1")
    toproot.geometry("800x400")
    #toproot.pack(side="center")
    image2 =Image.open('4.jpg')
    image2 =image2.resize((800,400), Image.ANTIALIAS)

    background_image=ImageTk.PhotoImage(image2)

    background_label = tk.Label(toproot, image=background_image)

    background_label.image = background_image

    background_label.place(x=0, y=0) #, relwidth=1, relheight=1)
    ###################################################################################################################################################################
    
    
    toproot.title("------Model Testing Window------")
                   
    def validate_entry(inp):
        # vcmd = (tk.register(root.validate),'%d', '%i', '%P', '%s', '%S', '%v', '%V', '%W')
             # if inp in '0123456789,-+':
             #     try:
             #         float(inp)
             #         return True
             #     except ValueError:
             #         return False
             #     else:
             #         return False
        try:
            str(inp)
            # v=float(root.ent1.get())

        except:
            ms.showerror("Waring", "Please Enter Valid Entries")
            ms.showinfo("Message", "Please Check Testing Window")
            return False
        return True
    # def validate_entry(root, inp ):
    #    # if(action=='1'):
    #         if inp in '0123456789.-+':
    #             try:
    #                 float(inp)
    #                # return True
    #             except ValueError:
    #                 return False
    #             else:
    #                 return False
    #         else:
    #                 return True


     
    # width=650, height=350, bd=5, font=('times', 15, ' bold '),bg="white",fg="red")
    # 'ECG(mV)', 'EMG(mV)', 'HR(bpm)', 'RESP(mV)', 'Foot GSR(mV)', 'Hand GSR(mV)'
    label1 = tk.Label(toproot,text="ECG(mV)  ",bg="blue",fg="white",font=('times', 15, ' bold '))
    label1.place(x=20,y=10)
    
    label2 = tk.Label(toproot,text="EMG(mV)  ",bg="blue",fg="white",font=('times', 15, ' bold '))
    label2.place(x=20,y=50)

    label3 = tk.Label(toproot,text="Foot GSR(mV) ",bg="blue",fg="white",font=('times', 15, ' bold '))
    label3.place(x=20,y=100)

    label4 = tk.Label(toproot,text="Hand GSR(mV) ",bg="blue",fg="white",font=('times', 15, ' bold '))
    label4.place(x=20,y=150)

    label5 = tk.Label(toproot,text="HR(bpm)",fg="white",bg="blue",font=('times', 15, ' bold '))
    label5.place(x=20,y=200)

    label6 = tk.Label(toproot,text="RESP(mV) ",fg="white",bg="blue",font=('times', 15, ' bold '))
    label6.place(x=20,y=250)
    
    ent1= tk.Entry(toproot,width=15,fg="black",font=('times', 15, ' bold '),validate='key',vcmd=(root.register(validate_entry), '%P'))
    ent1.place(x=250,y=10)
   # ent1.insert(0, 0.01822)
    
    ent2= tk.Entry(toproot,width=15, fg="black",font=('times', 15, ' bold '),validate='key',vcmd=(toproot.register(validate_entry), '%P'))
    ent2.place(x=250,y=50)
    #ent2.insert(0, -0.0033)
    
    ent3= tk.Entry(toproot,width=15, fg="black",font=('times', 15, ' bold '),validate='key',vcmd=(toproot.register(validate_entry),'%P'))
    ent3.place(x=250,y=100)
    #ent3.insert(0, 1.780)

    ent4= tk.Entry(toproot,width=15, fg="black",font=('times', 15, ' bold '),validate='key',vcmd=(toproot.register(validate_entry), '%P'))
    ent4.place(x=250,y=150)
    #ent4.insert(0, 9.395)

    ent5= tk.Entry(toproot,width=15, fg="black",font=('times', 15, ' bold '),validate='key',vcmd=(toproot.register(validate_entry), '%P'))
    ent5.place(x=250,y=200)
    #ent5.insert(0, 86.2955)

    ent6= tk.Entry(toproot,width=15, fg="black",font=('times', 15, ' bold '),validate='key',vcmd=(toproot.register(validate_entry),  '%P'))
    ent6.place(x=250,y=250)
    #ent6.insert(0, 10.757)
    
    def topwindow():
       toproot.destroy()   
    
    #buttonA = tk.Button(toproot ,bg="fireBrick1",text='Prediction', width=25, command=testing,font=('times', 15, ' bold '))
    #buttonA.PLACE(x=200,y=250)

    #buttonB = tk.Button(toproot,bg="fireBrick1", text='Exit', width=25, command=topwindow,font=('times', 15, ' bold '))
    #buttonB.place(x=300,y=250)
    
    #ent1.focus_set()
    #frame_topw = tk.Frame(toproot, width=200, height=100, bd=5, bg="blue3")
    #frame_topw.pack(side=tk.BOTTOM)
    
    buttonA = tk.Button(toproot ,bg="lightblue",text='Prediction', width=10, command=testing,font=('times', 15, ' bold '))
    buttonA.place(x=50,y=330)
    buttonB = tk.Button(toproot,bg="lightblue", text='Exit', width=10, command=topwindow,font=('times', 15, ' bold '))
    buttonB.place(x=200,y=330)
#    ent1.focus_set()
   #'ECG(mV)', 'EMG(mV)', 'Foot GSR(mV)', 'Hand GSR(mV)', 'HR(bpm)', 'RESP(mV)'
   #  [-0.005, 0.49, 8.257, 5.853, 66.142, 45.998] [0]
   #  [0.001, 0.931, 5.91, 19.773, 99.065, 35.59] [1]
  
    
#    label = tk.Label(toproot,text="--- Test Result---",bg="lightblue",fg="dark green",font=('times', 10, ' bold '))
#    label.pack()
#    counter_label(label)
    #frame_topw = tk.Frame(toproot, width=200, height=100, bd=5, bg="khaki")
    #frame_topw.place(x=100,y=300)
    
    
    
#################################################################################################################
def window():
    root.destroy()


button1 = tk.Button(frame_alpr, text=" Load Data ", command=Load_data,width=12, height=1, font=('times', 15, ' bold '),bg="#CCCCFF",fg="black")
button1.place(x=10, y=50)



button2 = tk.Button(frame_alpr, text="Process Data", command=Process_d, width=12, height=1, font=('times', 15, ' bold '),bg="#CCCCFF",fg="black")
button2.place(x=10, y=150)

button3 = tk.Button(frame_alpr, text="Train Model", command=train_model, width=12, height=1, font=('times', 15, ' bold '),bg="white",fg="black")
button3.place(x=10, y=250)

button4 = tk.Button(frame_alpr, text="Test Model", command=test_window,width=12, height=1, font=('times', 15, ' bold '),bg="#CCCCFF",fg="black")
button4.place(x=10, y=350)

#button5 = tk.Button(frame_alpr, text="Show Graph", command=graph_in_canvas,width=12, height=1,bg="white",fg="black", font=('times', 15, ' bold '))
#button5.place(x=10, y=350)
#

exit = tk.Button(frame_alpr, text="Exit", command=window, width=12, height=1, font=('times', 15, ' bold '),bg="red",fg="black")
exit.place(x=10, y=450)



root.mainloop()