import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,classification_report
from sklearn.pipeline import Pipeline
from sklearn import svm

import joblib
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler

from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import StratifiedKFold
# from tpot import TPOTClassifier
import matplotlib.pyplot as plt
from scipy import signal 
import pickle

import sklearn.metrics
from sklearn.model_selection import cross_val_score
from sklearn.metrics import precision_recall_fscore_support 

# pd.set_option('display.max_columns', None)
# pd.set_option('display.max_rows', None)
# pd.set_option('display.max_colwidth', -1)


def main(testing,Tval):

    colset=['ECG', 'EMG', 'HR','RESP','footGSR', 'handGSR', 'stress']
    
    dataframe_hrv = pd.read_csv("dataset/dataframe_hrv.csv",usecols=colset)
    
    dataframe_hrv.columns = ['ECG(mV)', 'EMG(mV)', 'HR(bpm)', 'RESP(mV)', 'Foot GSR(mV)', 'Hand GSR(mV)','Stress']
    
    
    def fix_stress_labels(df='',label_column='Stress'):
        df['Stress'] = np.where(df['Stress']>=0.5, 1, 0)
        return df
    
    
    def missing_values(df):
        df = df.reset_index()
        df = df.replace([np.inf, -np.inf], np.nan)
        df[~np.isfinite(df)] = np.nan
        df['HR(bpm)'].fillna((df['HR(bpm)'].mean()), inplace=True)
        df['HR(bpm)'] = signal.medfilt(df['HR(bpm)'],13)
    
        df.fillna(df.mean(),inplace=True)
        
        return df
    
    
    dataframe_hrv = fix_stress_labels(dataframe_hrv)
    dataframe_hrv = missing_values(dataframe_hrv)
    dataframe_hrv.reset_index(drop=True, inplace=True)
    counts = dataframe_hrv['Stress'].value_counts()
    print(counts[0], counts[1])
    
    
    df=dataframe_hrv
    
    X_train, X_test, y_train, y_test = train_test_split(
        df[['ECG(mV)', 'EMG(mV)', 'Foot GSR(mV)', 'Hand GSR(mV)', 'HR(bpm)', 'RESP(mV)']], df['Stress'],
        test_size=0.30, random_state=12345)
    
    # Min-Max Scaling
    
    minmax_scale = preprocessing.MinMaxScaler().fit(
        df[['ECG(mV)', 'EMG(mV)', 'Foot GSR(mV)', 'Hand GSR(mV)', 'HR(bpm)', 'RESP(mV)']])
    df_minmax = minmax_scale.transform(
        df[['ECG(mV)', 'EMG(mV)', 'Foot GSR(mV)', 'Hand GSR(mV)', 'HR(bpm)', 'RESP(mV)']])
    X_train_norm, X_test_norm, y_train_norm, y_test_norm = train_test_split(df_minmax, df['Stress'],
                                                                            test_size=0.30, random_state=12345)
    # steps = [('scaler', StandardScaler()), ('SVM', SVC())]
    # pipeline = Pipeline(steps)
    # parameters = {'SVM__C':[0.001,0.1,10,100,10e5], 'SVM__gamma':[0.1,0.01]}
    
    if not testing:
        pipeline = Pipeline([
            ('clf', DecisionTreeClassifier(criterion='entropy'))
        ])
        
        parameters = {
            'clf__max_depth': (150, 155, 160),
            'clf__min_samples_split': (1, 2, 3),
            'clf__min_samples_leaf': (1, 2, 3)
        }
        
        grid_search = GridSearchCV(pipeline, parameters, n_jobs=-1, verbose=1, scoring='accuracy')
        grid_search.fit(X_train_norm, y_train_norm.values.ravel())
        
        joblib.dump(grid_search,'ClfDT.pkl')
        
        print('Best Score:- %0.3f' % grid_search.best_score_)
        
        A1='DecisionTree Modeling Best Score:- %0.3f' % round(grid_search.best_score_ * 100,2)
        
        print('Best paramaters set:- ')
        best_paramaters = grid_search.best_estimator_.get_params()
        for param_name in sorted(parameters.keys()):
            print('\t%s %r' % (param_name, best_paramaters[param_name]))
        
        predictions = grid_search.predict(X_test_norm)
        print(classification_report(y_test_norm, predictions))
        
        A2=classification_report(y_test_norm, predictions)
        
        A=A1 + '\n' + A2
        
        
        
        
        
        parameters = [{'kernel': ['rbf'], 'gamma': [1e-3, 1e-4],
                             'C': [1, 10, 100, 1000]},
                            {'kernel': ['linear'], 'C': [1, 10, 100, 1000]}]
        
        
        grid_search = GridSearchCV(svm.SVC(C=5), parameters, n_jobs=-1, verbose=1, scoring='accuracy')
        grid_search.fit(X_train_norm, y_train_norm.values.ravel())
        
        joblib.dump(grid_search,'ClfSVM.pkl')
        
        print('Best Score:- %0.3f' % grid_search.best_score_)
        B1='SVM Modeling Best Score:- %0.3f' % round(grid_search.best_score_ * 100,2)
    
        print("Best parameters set found on development set:")
        print()
        print(grid_search.best_params_)
        print()
        print("Detailed classification report:")
        print()
        print("The model is trained on the full development set.")
        print("The scores are computed on the full evaluation set.")
        print()
        y_true, y_pred = y_test, grid_search.predict(X_test_norm)
        print(classification_report(y_true, y_pred))
        B2=classification_report(y_true, y_pred)
        print()
        
        B=B1 + '\n' + B2
        
    # A="Model Training done"

    # from sklearn.preprocessing import MinMaxScaler 
    
    # scaler = MinMaxScaler()  #.fit([[-0.005, 0.49, 8.257, 5.853, 66.142, 45.998]])

    # clf = joblib.load('ClfSVM.pkl')
    # print()
    # print('Prediction using SVM')
    
    # pred_data_norm = scaler.fit_transform([[-0.005, 0.49, 8.257, 5.853, 66.142, 45.998]])
    # pred = clf.predict(pred_data_norm)
    # print('Predicted class for dataset [-0.005,0.49,8.257,5.853,66.142,45.998]:- ', pred)
    
    # scaler = MinMaxScaler().fit([[0.001, 0.931, 5.91, 19.773, 99.065, 35.59]])

    # pred_data_norm = scaler.fit_transform([[0.001, 0.931, 5.91, 19.773, 99.065, 35.59]])
    # pred = clf.predict(pred_data_norm)
    # print('Predicted class for dataset [0.001,0.931,5.91,19.773,99.065,35.59]:- ', pred)

    if testing:
        # Prediction of stress/no stress class on new dataset
        clf = joblib.load('ClfDT.pkl')
        print()
        print('Prediction using SVM')
        pred_data_norm = minmax_scale.transform([Tval])
        pred = clf.predict(pred_data_norm)
        
        return pred
    else:
        return A,B

        
    # # Prediction of stress/no stress class on new dataset
    
    # print()
    # print('Prediction using Decision Tree Classifier')
    # pred_data_norm = minmax_scale.transform([[-0.005, 0.49, 8.257, 5.853, 66.142, 45.998]])
    # pred = grid_search.predict(pred_data_norm)
    # print('Predicted class for dataset [-0.005,0.49,8.257,5.853,66.142,45.998]:- ', pred)
    
    # pred_data_norm = minmax_scale.transform([[0.001, 0.931, 5.91, 19.773, 99.065, 35.59]])
    # pred = grid_search.predict(pred_data_norm)
    # print('Predicted class for dataset [0.001,0.931,5.91,19.773,99.065,35.59]:- ', pred)
    
    # print()
    # print('Prediction using SVM')
    # pred_data_norm = minmax_scale.transform([[-0.005, 0.49, 8.257, 5.853, 66.142, 45.998]])
    # pred = grid_search.predict(pred_data_norm)
    # print('Predicted class for dataset [-0.005,0.49,8.257,5.853,66.142,45.998]:- ', pred)
    
    # pred_data_norm = minmax_scale.transform([[0.001, 0.931, 5.91, 19.773, 99.065, 35.59]])
    # pred = grid_search.predict(pred_data_norm)
    # print('Predicted class for dataset [0.001,0.931,5.91,19.773,99.065,35.59]:- ', pred)
    
